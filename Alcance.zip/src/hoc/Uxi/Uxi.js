const Uxi = ( props ) => props.children;
export default Uxi;