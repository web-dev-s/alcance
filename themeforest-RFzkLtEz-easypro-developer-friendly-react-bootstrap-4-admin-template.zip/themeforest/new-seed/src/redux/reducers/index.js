import themeReducer from './themeReducer';
import sidebarReducer from './sidebarReducer';
import rtlReducer from './rtlReducer';

export {
  themeReducer,
  sidebarReducer,
  rtlReducer,
};
